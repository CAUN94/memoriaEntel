# Requirements

- PHP version >= 5.3.7
- Laravel >= 4.1
- PHPOffice PHPExcel >= 1.8.0 (included by composer.json)
- PHP extension php_zip enabled (required if you need PHPExcel to handle .xlsx .ods or .gnumeric files)
- PHP extension php_xml enabled
- PHP extension php_gd2 enabled (optional, but required for exact column width autocalculation)