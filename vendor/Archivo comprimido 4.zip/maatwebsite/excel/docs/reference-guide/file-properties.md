# Available file properties

Properties that can be set with `$excel->set{$property}()`

| Property name  |
| ------------- |
|creator
|lastModifiedBy
|title
|description
|subject
|keywords
|category
|manager
|company